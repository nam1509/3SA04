import { StyleSheet } from 'react-native';

const Styles = StyleSheet.create({
 container: {},

  view: {
    backgroundColor: '#FF6699',
    width: '20%',
    marginLeft: '5%',
    marginRight: '5%',
    padding: 15,
  },

  zipcode: {
    marginLeft: '5%',
    padding: 15,
    flexDirection:'row',
  },


});

export default Styles
