import React from 'react';
import Styles from './style';
import { StyleSheet, Text, View, } from 'react-native';

export default class App extends React.Component {
    render() {
        const { main, description, temp } = this.props;
    
        return (
          <View>
 <Text>{this.props.main}</Text>
 <Text>{this.props.description}</Text>
 <Text>{this.props.temp}°C</Text>

 </View>

        );
    }
}
const styles = StyleSheet.create({
    container: { paddingTop: 25 ,},
    
    gg: {flexDirection:'column' , alignItems:'center' , height:50 },
    item:{
        fontSize: 20,
        height:60 
    
    },
    });
    